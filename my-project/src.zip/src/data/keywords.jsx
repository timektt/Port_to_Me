export const keywords = [
    {
      id: 'compilersinterpreters',
      title: 'Compilersinterpreters',
      path: '/courses/basic-programming/101_introduction_to_programming/compilersinterpreters',
      tags: ['101', 'compilersinterpreters', 'basic', 'programming', 'introduction', 'to'],
    },
    {
      id: 'computerexecution',
      title: 'Computerexecution',
      path: '/courses/basic-programming/101_introduction_to_programming/computerexecution',
      tags: ['101', 'computerexecution', 'programming', 'basic', 'introduction', 'to'],
    },
    {
      id: 'programminglanguages',
      title: 'Programminglanguages',
      path: '/courses/basic-programming/101_introduction_to_programming/programminglanguages',
      tags: ['101', 'programminglanguages', 'basic', 'programming', 'introduction', 'to'],
    },
    {
      id: 'setupenvironment',
      title: 'Setupenvironment',
      path: '/courses/basic-programming/101_introduction_to_programming/setupenvironment',
      tags: ['101', 'basic', 'programming', 'introduction', 'to', 'setupenvironment'],
    },
    {
      id: 'whatisprogramming',
      title: 'Whatisprogramming',
      path: '/courses/basic-programming/101_introduction_to_programming/whatisprogramming',
      tags: ['101', 'whatisprogramming', 'basic', 'programming', 'introduction', 'to'],
    },
  ];
  