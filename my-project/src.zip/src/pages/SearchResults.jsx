import { useLocation, Link } from "react-router-dom";
import { useMemo } from "react";
import { keywords } from "../data/keywords";
import Fuse from "fuse.js";

function useQuery() {
  return new URLSearchParams(useLocation().search);
}

const SearchResults = () => {
  const query = useQuery().get("q")?.toLowerCase() || "";

  const fuse = new Fuse(keywords, {
    keys: ["title", "tags"],
    threshold: 0.3,
  });

  const filtered = useMemo(() => {
    return fuse.search(query).map((result) => result.item);
  }, [query]);

  return (
    <div className="p-6 max-w-3xl mx-auto">
      <h2 className="text-2xl font-bold mb-4">Results for: {query}</h2>
      {filtered.length === 0 ? (
        <p>No results found.</p>
      ) : (
        <ul className="space-y-3">
          {filtered.map((item) => (
            <li key={item.id}>
              <Link to={item.path} className="text-blue-500 hover:underline">
                {item.title}
              </Link>
              <p className="text-sm text-gray-500">{item.tags.join(", ")}</p>
            </li>
          ))}
        </ul>
      )}
    </div>
  );
};

export default SearchResults;