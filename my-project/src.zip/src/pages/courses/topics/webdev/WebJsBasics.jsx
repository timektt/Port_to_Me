import React from "react";

const WebJsBasics = () => {
  return (
    <div className="p-6">
      <h1 className="text-3xl font-bold">JavaScript Basics</h1>
      <p>JavaScript เป็นภาษาที่ใช้ในการเพิ่มความสามารถแบบโต้ตอบให้กับเว็บเพจ</p>
    </div>
  );
};

export default WebJsBasics;
