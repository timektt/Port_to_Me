import React from "react";

const Algorithms = () => {
  return (
    <div className="p-6">
      <h1 className="text-3xl font-bold">Basic Algorithms</h1>
      <p>Algorithms are fundamental to programming and problem-solving.</p>
    </div>
  );
};

export default Algorithms; // ✅ ต้องมี `export default`
