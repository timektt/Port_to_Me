import React, { useState, useEffect } from "react";
import { useNavigate, Outlet, useParams } from "react-router-dom";
import Navbar from "../../components/common/Navbar";
import SupportMeButton from "../../support/SupportMeButton";
import Comments from "../../components/common/Comments";
import Breadcrumb from "../../components/common/Breadcrumb";

// ✅ ตรวจสอบว่าไฟล์ NodeSidebar และ NodeMobileMenu มีอยู่จริง
import NodeSidebar from "../../components/common/sidebar/NodeJsSidebar"; 
import NodeMobileMenu from "../../components/common/sidebar/MobileMenus/NodeMobileMenu"; 


import NodeIntro from "./pages/courses/topics/nodejs/101_node_basics/NodeIntro";
import NodeSetup from "./pages/courses/topics/nodejs/101_node_basics/NodeSetup";
import NodeJsRunCode from "./pages/courses/topics/nodejs/101_node_basics/NodeJsRunCode";
import NodeModules from "./pages/courses/topics/nodejs/101_node_basics/NodeModules";
import NodeNpmYarn from "./pages/courses/topics/nodejs/101_node_basics/NodeNpmYarn";

// Node.js 201
import AsyncCallbacks from "./pages/courses/topics/nodejs/201_async_js/AsyncCallbacks";
import PromisesAsyncAwait from "./pages/courses/topics/nodejs/201_async_js/PromisesAsyncAwait";
import EventEmitter from "./pages/courses/topics/nodejs/201_async_js/EventEmitter";
import StreamsBuffer from "./pages/courses/topics/nodejs/201_async_js/StreamsBuffer";

// Node.js 202
import EventLoop from "./pages/courses/topics/nodejs/202_event_loop/EventLoop";
import TimersIO from "./pages/courses/topics/nodejs/202_event_loop/TimersIO";
import ProcessNextTick from "./pages/courses/topics/nodejs/202_event_loop/ProcessNextTick";


// Node.js 203
import RestApiBasics from "./pages/courses/topics/nodejs/203_api_development/RestApiBasics";
import HandlingHttpRequests from "./pages/courses/topics/nodejs/203_api_development/HandlingHttpRequests";
import MiddlewareConcepts from "./pages/courses/topics/nodejs/203_api_development/MiddlewareConcepts";


// Node.js 204
import ExpressIntro from "./pages/courses/topics/nodejs/204_express/ExpressIntro";
import ExpressRouting from "./pages/courses/topics/nodejs/204_express/ExpressRouting";
import ExpressMiddleware from "./pages/courses/topics/nodejs/204_express/ExpressMiddleware";
// Node.js 205
import MongoDBIntegration from "./pages/courses/topics/nodejs/205_database/MongoDBIntegration";
import PostgreSQLIntegration from "./pages/courses/topics/nodejs/205_database/PostgreSQLIntegration";
import MongooseORM from "./pages/courses/topics/nodejs/205_database/MongooseORM";
import KnexJSPostgreSQL from "./pages/courses/topics/nodejs/205_database/KnexJSPostgreSQL";


const lessons = [
  { id: "101", title: "Basic Node.js", image: "/node1.jpg", path: "node-intro" },
  { id: "201", title: "Asynchronous JavaScript", image: "/node2.jpg", path: "async-callbacks" },
  { id: "202", title: "Event Loop & Async", image: "/node3.webp", path: "event-loop" },
  { id: "203", title: "API Development", image: "/node1.jpg", path: "rest-api-basics" },
  { id: "204", title: "Express.js", image: "/node2.jpg", path: "express-intro" },
  { id: "205", title: "Database", image: "/node3.webp", path: "mongodb-integration" },
];

const NodeSeries = ({ theme, setTheme }) => {
  const navigate = useNavigate();
  const { "*": subPage } = useParams(); // ✅ ตรวจสอบหัวข้อที่ถูกเลือก
  const [sidebarOpen, setSidebarOpen] = useState(false);
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  useEffect(() => {
    console.log("🚀 NodeSeries Loaded"); // ✅ Debug: ตรวจสอบ Component โหลด
    const handleResize = () => {
      if (window.innerWidth >= 768) {
        setSidebarOpen(false);
        setMobileMenuOpen(false);
      }
    };

    window.addEventListener("resize", handleResize);
    return () => window.removeEventListener("resize", handleResize);
  }, []);

  return (
    <div className={`min-h-screen flex flex-col ${theme === "dark" ? "bg-gray-900 text-white" : "bg-gray-100 text-black"}`}>
      
      {/* ✅ Navbar */}
      <div className="fixed top-0 left-0 w-full z-50">
        <Navbar theme={theme} setTheme={setTheme} onMenuToggle={() => setMobileMenuOpen(!mobileMenuOpen)} />
      </div>

      {/* ✅ Sidebar (ไม่ทับ Navbar) */}
      <div className="hidden md:block fixed left-0 top-16 h-[calc(100vh-4rem)] w-64 z-40">
        <NodeSidebar theme={theme} sidebarOpen={sidebarOpen} setSidebarOpen={setSidebarOpen} />
      </div>

      {/* ✅ Mobile Sidebar */}
      {mobileMenuOpen && (
        <div className="fixed inset-0 bg-black bg-opacity-50 z-50">
          <NodeMobileMenu onClose={() => setMobileMenuOpen(false)} theme={theme} setTheme={setTheme} />
        </div>
      )}

      {/* ✅ Main Content */}
      <main className="flex-1 md:ml-64 p-4 md:p-6 mt-16 relative z-10">
        <div className="max-w-5xl mx-auto">
          
          {/* ✅ Breadcrumb Navigation */}
          <Breadcrumb courseName="Node.js Series" theme={theme} />

          {/* ✅ ถ้ามี subPage แสดงเนื้อหาของหัวข้อนั้น */}
          {subPage ? (
            <Outlet />
          ) : (
            <>
              <h1 className="text-3xl md:text-4xl font-bold mt-4">Node.js Series</h1>
              <p className="mt-2 text-lg">เลือกหัวข้อจาก Sidebar เพื่อเริ่มต้นเรียนรู้เกี่ยวกับ Node.js</p>

              {/* ✅ Warning Box */}
              <div className={`p-4 mt-4 rounded-md shadow-md flex flex-col gap-2 ${theme === "dark" ? "bg-yellow-700 text-white" : "bg-yellow-300 text-black"}`}>
                <strong className="text-lg flex items-center gap-2">⚠ WARNING</strong>
                <p>เอกสารฉบับนี้ยังอยู่ในระหว่างการทำ Series ของ Node.js...</p>
                <p>สามารถติดตามผ่านทาง YouTube: 
                  <a href="https://youtube.com" className="text-blue-400 hover:underline ml-1">supermhee</a>
                </p>
              </div>

              {/* ✅ Table Section (Desktop) */}
              <div className="hidden sm:block overflow-x-auto mt-6">
                <table className={`w-full border rounded-lg shadow-lg ${theme === "dark" ? "border-gray-700" : "border-gray-300"}`}>
                  <thead className={`${theme === "dark" ? "bg-gray-800 text-white" : "bg-gray-300 text-black"} text-lg`}>
                    <tr>
                      <th className="p-4 border-b-2 w-1/6">ตอน</th>
                      <th className="p-4 border-b-2 w-1/3">หัวข้อ</th>
                      <th className="p-4 border-b-2 w-1/6">ดูเนื้อหา</th>
                    </tr>
                  </thead>
                  <tbody>
                    {lessons.map((lesson, index) => (
                      <tr key={lesson.id} className={`${index % 2 === 0 ? (theme === "dark" ? "bg-gray-700" : "bg-gray-100") : ""} hover:bg-gray-500 transition duration-200`}>
                        <td className="p-4 text-center border-b text-lg font-semibold">{lesson.id}</td>
                        <td className="p-4 border-b text-lg">{lesson.title}</td>
                        <td className="p-4 border-b text-center">
                          <button
                            onClick={() => navigate(`/courses/nodejs-series/${lesson.path}`)}
                            className="text-green-400 hover:underline"
                          >
                            เข้าเรียน
                          </button>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>

              {/* ✅ Responsive (Mobile) */}
              <div className="sm:hidden mt-6 space-y-4">
                {lessons.map((lesson) => (
                  <div key={lesson.id} className={`p-4 border rounded-lg shadow-md ${theme === "dark" ? "bg-gray-800 text-white" : "bg-white text-black"}`}>
                    <h2 className="text-xl font-semibold">{lesson.title}</h2>
                    <img src={lesson.image} className="w-full h-40 mt-2 rounded-lg shadow-md object-cover" alt={lesson.title} />
                    <div className="mt-4 flex justify-between">
                      <button
                        onClick={() => navigate(`/courses/nodejs-series/${lesson.path}`)}
                        className="text-green-400 hover:underline"
                      >
                        เข้าเรียน
                      </button>
                    </div>
                  </div>
                ))}
              </div>
            </>
          )}

          {/* ✅ Comments Section */}
          <Comments theme={theme} />
        </div>
      </main>

      <SupportMeButton />
    </div>
  );
};

export default NodeSeries;
